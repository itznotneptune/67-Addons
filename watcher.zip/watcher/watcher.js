// ------------------------------ Imports ------------------------------ \\

import Dungeon from "../../BloomCore/dungeons/Dungeon"
import { wcData } from "./watcherUtil"
import { entryMessages } from "../../BloomCore/utils/Utils"
import Settings from "../../67-Addons/configs"
const EntityArmorStand = Java.type("net.minecraft.entity.item.EntityArmorStand")
const S32PacketConfirmTransaction = Java.type("net.minecraft.network.play.server.S32PacketConfirmTransaction")

// ------------------------------ Watcher Data ------------------------------ \\

let hasEnteredBlood = false
let bloodStartTime = 0
let bloodSpeakTime = 0
let dialogueTime = 0
let premoveX = 0
let premoveZ = 0
let coordChecking = false
let firstCoords = false
var watcherMoved = false
var watcherCanMoveTime = 0
var guessingMove = false
var campTime = 0
var playOnce = false
var ticks = 0
var otherticks = 0
var dialogueTicks = 0
var moveTicks = 0
var campTicks = 0
var inBoss = false
var guessedMove = 0
var guessedMoveSecs = 0
var hasSaidDialogue = false

var wasOpen = false

// ------------------------------ World Reset ------------------------------ \\

register("worldLoad", () => {
    hasEnteredBlood = false
    bloodStartTime = 0
    bloodSpeakTime = 0
    dialogueTime = 0
    premoveX = 0
    premoveZ = 0
    watcherMoved = false
    firstCoords = false
    watcherCanMoveTime = 0
    coordChecking = false
    bloodFinished = false
    watcherMoveTime = 0
    guessingMove = false
    campTime = 0
    playOnce = false
    ticks = 0
    otherticks = 0
    dialogueTicks = 0
    moveTicks = 0
    campTicks = 0
    inBoss = false
    guessedMove = 0
    guessedMoveSecs = 0
    hasSaidDialogue = false
})

// ------------------------------ Message Detection ------------------------------ \\

register("chat", (event) => {
    if (!Settings.wcToggle) return;

    if (ChatLib.getChatMessage(event, false).startsWith("[BOSS]") && Dungeon.inDungeon) {
        if (Settings.hideCampInBoss) {
            entryMessages.forEach(msg => {
                if (msg == ChatLib.getChatMessage(event, false)) {
                    inBoss = true
                }
            })
        }
        if (Settings.bossMsg) {
            cancel(event)
        }
    }

    // Blood Start
    if (ChatLib.getChatMessage(event, false).startsWith("[BOSS] The Watcher:") && !hasEnteredBlood) {
        hasEnteredBlood = true
        bloodStartTime = Date.now()
    }

    // Watcher dialogue that signals when to prepare to kill blood mobs
    if (ChatLib.getChatMessage(event, false).startsWith("[BOSS] The Watcher: Let's see how you can handle this.")) {
        bloodSpeakTime = Date.now()
        dialogueTime = (bloodSpeakTime - bloodStartTime) / 1000
        dialogueTicks = ticks
        watcherCanMoveTime = dialogueTime + parseFloat(2.5)
        // Fast Camp
        if (dialogueTime > parseFloat(22)) {
            if(Settings.chatInfo){ChatLib.chat(`§6§l[§3WA§6§l]§r §bWatcher took §d§l${dialogueTime.toFixed(1)}s§r§b to reach dialogue!`)}
            guessedMove = bloodStartTime + 24000
            guessedMoveSecs = 24
            if (Settings.dialogueNotif) {
                if (!Settings.babyMode){World.playSound("mob.wolf.bark", 10, 1)}
                if (!Settings.babyMode){Client.showTitle(`§4§lFAST WATCHER`, `§bTook §d${dialogueTime.toFixed(1)}s§b!`, 2, 45, 10)}
                if (!Settings.babyMode){Client.showTitle(`§4§lFAST WATCHER`, `§bTook §d${dialogueTime.toFixed(1)}s§b!`, 2, 45, 10)}
                if (!Settings.babyMode){hasSaidDialogue = true}
            }
        // Average Camp
        } else if (dialogueTime >= parseFloat(22) && dialogueTime < parseFloat(25)) {
            if (Settings.chatInfo){ChatLib.chat(`§6§l[§3WA§6§l]§r §bWatcher took §d§l${dialogueTime.toFixed(1)}s§r§b to reach dialogue!`)}
            guessedMove = bloodStartTime + 28000
            guessedMoveSecs = 28
            if (Settings.dialogueNotif) {
                if (!Settings.babyMode){World.playSound("mob.cat.meow", 10, 1)}
                if (!Settings.babyMode){Client.showTitle(`§4§lFAST WATCHER`, `§bTook §d${dialogueTime.toFixed(1)}s§b!`, 2, 45, 10)}
                if (!Settings.babyMode){Client.showTitle(`§4§lFAST WATCHER`, `§bTook §d${dialogueTime.toFixed(1)}s§b!`, 2, 45, 10)}
                if (!Settings.babyMode){hasSaidDialogue = true}
            }
        // Slow Camp
        } else if (dialogueTime >= parseFloat(25)) {
            if (Settings.chatInfo){ChatLib.chat(`§6§l[§3WA§6§l]§r §bWatcher took §d§l${dialogueTime.toFixed(1)}s§r§b to reach dialogue!`)}
            guessedMove = bloodStartTime + 32000
            guessedMoveSecs = 32
            if (Settings.dialogueNotif) {
                if (!Settings.babyMode){World.playSound("mob.wolf.bark", 10, 1)}
                if (!Settings.babyMode){Client.showTitle(`§4§lFAST WATCHER`, `§bTook §d${dialogueTime.toFixed(1)}s§b!`, 2, 45, 10)}
                if (!Settings.babyMode){Client.showTitle(`§4§lFAST WATCHER`, `§bTook §d${dialogueTime.toFixed(1)}s§b!`, 2, 45, 10)}
                if (!Settings.babyMode){hasSaidDialogue = true}
            }
        }
    }

    if (ChatLib.getChatMessage(event, false).startsWith("[BOSS] The Watcher:") && bloodSpeakTime != 0 && !watcherMoved) {
        if (((Date.now() - bloodStartTime) / 1000) >= 40) {
            if (Settings.chatInfo){ChatLib.chat(`§6§l[§3WA§6§l]§r §bGuessing Watcher moved at §d§l${guessedMoveSecs}s!§r`)}
            watcherMoveTime = guessedMove
            moveTicks = (guessedMoveSecs * 20)
            watcherMoved = true
            guessingMove = true
        }
    }

    // Blood camp breakdown
    if (ChatLib.getChatMessage(event, false).startsWith("[BOSS] The Watcher: You have proven yourself. You may pass.") && bloodStartTime != 0) {
        campTicks = ticks
        bloodFinished = true
        campTime = ((Date.now() - bloodStartTime) / 1000).toFixed(2)
        if(!Settings.chatInfo) return;
        if(!guessingMove) {
            if(Settings.chatInfoStyle == 0) {
                ChatLib.chat(`§6§l[§3WA§6§l]§r §bBlood camp took §d§l${((Date.now() - bloodStartTime) / 1000).toFixed(1)}s§r §7(${((campTicks) / 20).toFixed(1)})§b!`)
            } else if(Settings.chatInfoStyle == 1) {
                ChatLib.chat(`§6§l[§3WA§6§l]§r §bPost move camp took §d§l${((Date.now() - watcherMoveTime) / 1000).toFixed(1)}s§r §7(${((campTicks - moveTicks) / 20).toFixed(1)})§b!`)
            } else if(Settings.chatInfoStyle == 2) {
                ChatLib.chat(`§6§l[§3WA§6§l]§r §bBlood camp breakdown: §d${((Date.now() - bloodStartTime) / 1000).toFixed(1)}s§r §7(${((campTicks) / 20).toFixed(1)})§r§6§l / §d${((Date.now() - watcherMoveTime) / 1000).toFixed(1)}s§r §7(${((campTicks - moveTicks) / 20).toFixed(1)})§b!`)
            }
            } else{
            if(Settings.chatInfoStyle == 0) {
                ChatLib.chat(`§6§l[§3WA§6§l]§r §bBlood camp took §d§l${((Date.now() - bloodStartTime) / 1000).toFixed(1)}s§r §7(${((campTicks) / 20).toFixed(1)})§b!`)
            } else if(Settings.chatInfoStyle == 1) {
                ChatLib.chat(`§6§l[§3WA§6§l]§r §bGuessing post move camp took §d§l${(guessedMoveSecs)}s§r §7(${(guessedMove)})§b!`)
            } else if(Settings.chatInfoStyle == 2) {
                ChatLib.chat(`§6§l[§3WA§6§l]§r §bBlood camp breakdown: §d${((Date.now() - bloodStartTime) / 1000).toFixed(1)}s§r §7(${((campTicks) / 20).toFixed(1)})§r§6§l / §c§o${((Date.now() - guessedMove) / 1000).toFixed(1)}s§r §7(${((campTicks - moveTicks) / 20).toFixed(1)})§b!`)
            }
        }
    }
})

// Stuff for easy mode
register("step", () => {
    if(!Settings.wcToggle || !Dungeon.inDungeon) return;
    if(hasSaidDialogue) return;
    if(Settings.babyMode && Settings.dialogueNotif && bloodSpeakTime != 0 && ((Date.now() - bloodSpeakTime) / 1000) >= 1.5) {
        if (guessedMoveSecs == 24) {
            World.playSound("mob.wolf.bark", 10, 1)
            Client.showTitle(`§4§lFAST WATCHER`, `§bTook §d${dialogueTime.toFixed(1)}s§b!`, 2, 45, 10)
            Client.showTitle(`§4§lFAST WATCHER`, `§bTook §d${dialogueTime.toFixed(1)}s§b!`, 2, 45, 10)
        } else if (guessedMoveSecs == 28) {
            World.playSound("mob.cat.meow", 10, 1)
            Client.showTitle(`§cWatcher Ready`, `§bTook §d${dialogueTime.toFixed(1)}s§b!`, 2, 45, 10)
            Client.showTitle(`§cWatcher Ready`, `§bTook §d${dialogueTime.toFixed(1)}s§b!`, 2, 45, 10)
        }else if(guessedMoveSecs == 30){
            World.playSound("mob.wither.shoot", 10, 1)
            Client.showTitle(`§8Slow Watcher zz`, `§bTook §d${dialogueTime.toFixed(1)}s§b!`, 2, 45, 10)
            Client.showTitle(`§8Slow Watcher zz`, `§bTook §d${dialogueTime.toFixed(1)}s§b!`, 2, 45, 10)
        }
        hasSaidDialogue = true
    }
}).setFps(5)

// Detecting when watcher moves

register("renderEntity", (entity, position, ticks, event) => {
    if (!Settings.wcToggle || !Dungeon.inDungeon) return;
    let mcEntity = entity.entity

    if (mcEntity instanceof EntityArmorStand && !bloodFinished) {
        if (entity.getName().includes("The Watcher") && bloodSpeakTime != 0) {
            if (!firstCoords && ((Date.now() - bloodStartTime) / 1000) >= parseFloat(watcherCanMoveTime)) {
                firstTime = Date.now()
                premoveX = entity.getX()
                premoveZ = entity.getZ()
                firstCoords = true
                coordChecking = true
            }

            if (coordChecking && !watcherMoved) {
                if (((Date.now() - bloodStartTime) / 1000) < 24) return
                if (parseFloat(premoveX).toFixed(1) != parseFloat(entity.getX()).toFixed(1) || parseFloat(premoveZ).toFixed(1) != parseFloat(entity.getZ()).toFixed(1)) {
                    watcherMoveTime = Date.now()
                    moveTicks = otherticks
                    if (Settings.chatInfo){ChatLib.chat(`§6§l[§3WA§6§l]§r §bWatcher moved at §d§l${((Date.now() - bloodStartTime) / 1000).toFixed(1)}s§r §7(${(moveTicks / 20).toFixed(1)})§b!`)}
                    coordChecking = false
                    watcherMoved = true
                }
            }
        }
    }
})


// Camp stats overlay

register("renderOverlay", () => {
    if(!Settings.wcToggle) return;
    if(Settings.hideCampInBoss && inBoss) return;
    if(Dungeon.inDungeon && Settings.campInfo) {
        Renderer.scale(wcData.campScale, wcData.campScale)
        Renderer.drawString(`&c&lWatcher Stats&r:`, wcData.campX, wcData.campY)
        //Dialogue time
        if(bloodStartTime == 0){
            Renderer.scale(wcData.campScale,wcData.campScale)
            Renderer.drawString(`&dDialogue&r: 0s`,wcData.campX,wcData.campY+(10*wcData.campScale))
        }else if(bloodStartTime != 0 && bloodSpeakTime == 0){
            Renderer.scale(wcData.campScale,wcData.campScale)
            Renderer.drawString(`&dDialogue&r: ${((Date.now() - bloodStartTime) / 1000).toFixed(2)}s &7(${(ticks / 20).toFixed(1)})`,wcData.campX,wcData.campY+(10*wcData.campScale))
        }else{
            Renderer.scale(wcData.campScale,wcData.campScale)
            Renderer.drawString(`&dDialogue&r: ${dialogueTime}s &7(${(dialogueTicks / 20).toFixed(1)})`,wcData.campX,wcData.campY+(10*wcData.campScale))
        }
        //Move time
        if(!watcherMoved){
            Renderer.scale(wcData.campScale,wcData.campScale)
            Renderer.drawString(`&dWatcher Move&r: Not Moved!`,wcData.campX,wcData.campY+(20*wcData.campScale))
        }else{
            Renderer.scale(wcData.campScale,wcData.campScale)
            Renderer.drawString(`&dWatcher Move&r: ${((watcherMoveTime - bloodStartTime) / 1000).toFixed(2)}s &7(${(moveTicks / 20).toFixed(1)})`,wcData.campX,wcData.campY+(20*wcData.campScale))
        }
        //Camp time
        if(!hasEnteredBlood){
            Renderer.scale(wcData.campScale,wcData.campScale)
            Renderer.drawString(`&dCamp&r: Not Started!`,wcData.campX,wcData.campY+(30*wcData.campScale))
        }else if(hasEnteredBlood && !bloodFinished){
            Renderer.scale(wcData.campScale,wcData.campScale)
            Renderer.drawString(`&dCamp&r: ${((Date.now() - bloodStartTime) / 1000).toFixed(2)}s &7(${(ticks / 20).toFixed(1)})`,wcData.campX,wcData.campY+(30*wcData.campScale))
        }else{
            Renderer.scale(wcData.campScale,wcData.campScale)
            Renderer.drawString(`&dCamp&r: ${campTime}s &7(${(campTicks / 20).toFixed(1)})`,wcData.campX,wcData.campY+(30*wcData.campScale))
        }
    }
})

// Packet-y stuff for more accurate times

register('packetReceived', () => {
    if(hasEnteredBlood) {
        ticks++
        otherTicks++
    }
}).setFilteredClass(S32PacketConfirmTransaction)

// Moving elements in a HUD

register("dragged", (dx, dy, x, y, left) => {
    if(Settings.campGui.isOpen()) {
        wcData.campX = x,
        wcData.campY = y
    }
})

register("renderOverlay", () => {
    if(!Settings.campGui.isOpen()) return
    Renderer.scale(1, 1)
    Renderer.drawString(`&c&lWatcher Stats&r:`, wcData.campX, wcData.campY)  
})

// Save data

function wasMoveGUIOpen() {
    if (Settings.campGui.isOpen() && wasOpen == false) {
        wasOpen = true
    }
    if (!Settings.campGui.isOpen() && wasOpen == true) {
        wcData.save()
        wasOpen = false
    }
}

register("step", () => {
    wasMoveGUIOpen()
})