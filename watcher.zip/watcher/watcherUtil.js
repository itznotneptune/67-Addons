import PogObject from "../../PogData"

export const wcData = new PogObject("67-Addons", {
    timerX: 150,
    timerY: 70,
    timerScale: 3,
    timerEnd: 0,
    campX: 180,
    campY: 230,
    campScale: 1,
})